package trabalhopoo;

import java.util.Random;

public class Oraculo 
{
    String nome;
    Guerreiro guerreiro;

    
    public void setNome(String nome) 
    {
        this.nome = nome;
    }
    public String getNome() 
    {
        return nome;
    }
    public void setVidas() 
    {
        Random vidas = new Random();
        this.guerreiro.vidas = vidas.nextInt(4)+ 9;
    }
    String prologoIntroducao()
    {
        return "Atenção " + guerreiro.getNome() + ".\nVocê tem " + guerreiro.getVidas() + " vidas.";
    }
    void loadLevel1()
    {
        Random r = new Random();
        int segredo = r.nextInt(100)+ 1;
        int palpite;
        
        while(this.guerreiro.getVidas() != 0)
        {
            palpite = InOut.leInt("Tente adivinhar o número secreto.\nVocê tem "+this.guerreiro.getVidas()+" vidas");
            if(palpite < segredo)
            {
                InOut.MsgSemIcone(this.getNome(),"O número secreto é MAIOR que "+palpite);
                this.guerreiro.vidas -= 1;
            }
            else if(palpite > segredo)
            {
                InOut.MsgSemIcone(this.getNome(),"O número secreto é MENOR que "+palpite);
                this.guerreiro.vidas -= 1;
            }
            else
            {
                InOut.MsgDeInformacao(this.getNome(), "Parabéns você descobriu o número secreto");
                break;
            }
        }
        if(this.guerreiro.getVidas() == 0)
        {
            if(this.decidirVidaExtra(this.guerreiro.misericordia()))
            {
                InOut.MsgSemIcone(this.getNome(),"Serei misericordioso, te darei uma vida extra");
                this.guerreiro.vidas++;
                this.prologoIntroducao();
            }
            else
            {
                InOut.MsgSemIcone(this.getNome(),"Não terei misericordia desta vez!");
                InOut.MsgSemIcone(this.nome, this.prologoPerdedor());
                System.exit(0);
            }
        }
    }
    void loadLevel2(String opcao)
    {
        
        Random r = new Random();
        int valorOrac = r.nextInt(5);
        int valorGuer = r.nextInt(5);
        String resultado;
        int soma = valorGuer + valorOrac;
              
        InOut.MsgSemIcone(this.getNome(), "Prepare-se para perder "+this.guerreiro.getNome()+"!\n"+"Você tem "+this.guerreiro.getVidas()+" vidas!");
        if("IMPAR".equals(opcao))
        {
            opcao = "ÍMPAR";
        }
        if(soma%2 == 0)
        {
            resultado = "PAR";
        }
        else
        {
            resultado = "ÍMPAR";
        }
        InOut.MsgDeAviso("resultado", "Oráculo escolheu: "+ valorOrac + "\n" + " Guerreiro escolheu: " + valorGuer);
        
        if(opcao.equals(resultado))
        {
            InOut.MsgDeAviso(this.getNome(), "PARABÉNS! Você ganhou este jogo");
        } 
        else
        {
            InOut.MsgDeAviso(this.getNome(), "Você perdeu este jogo!");
            this.guerreiro.vidas -= 1;
            if(this.guerreiro.vidas == 0)
            {
                if(this.decidirVidaExtra(this.guerreiro.misericordia()))
                {
                    InOut.MsgSemIcone(this.getNome(),"Serei misericordioso, te darei uma vida extra");
                    this.guerreiro.vidas++;
                }
                else
                {
                    InOut.MsgSemIcone(this.getNome(),"Não terei misericordia desta vez!");
                    InOut.MsgSemIcone(this.nome, this.prologoPerdedor());
                }
            }
        }
    }
    boolean decidirVidaExtra(String Misericordia)
    {
        int palavras = 0;
        for(int i = 0; i < Misericordia.length(); i++)
        {
          if(Misericordia.charAt(i) == ' ')
            {
                palavras++;
            }  
        }
        if(palavras > 4)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    String prologoVencedor()
    {
        return "Parabéns guerreiro "+this.guerreiro.getNome()+"! Você me venceu com "+this.guerreiro.getVidas()+" vidas";
    }
    String prologoPerdedor()
    {
        return "Eu te venci guerreiro "+this.guerreiro.getNome()+"! Você ficou com "+this.guerreiro.getVidas()+" vidas";
    }
}
