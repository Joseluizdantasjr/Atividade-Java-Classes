package trabalhopoo;

public class Guerreiro 
{
    String nome;
    int vidas;
    Oraculo oraculo;
    public void setNome(String nome) 
    {
        this.nome = nome;
    }
    
    String getNome()
    {
        return this.nome;
    }

    public int getVidas() 
    {
        return vidas;
    }
    
    String misericordia()
    {
        InOut.MsgDeAviso(this.oraculo.getNome(),"Atenção guerreiro "+this.getNome());
        return InOut.leString("Você tem "+ this.vidas +" vidas\nMe conveça a ter misericordia");
    }
    
    
}
