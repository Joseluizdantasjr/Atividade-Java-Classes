package trabalhopoo;
public class TrabalhoPOO {

    public static void main(String[] args) 
    {
        
       //Guerreiro
       Guerreiro g1 = new Guerreiro();
       
       g1.setNome(InOut.leString("Me diga seu nome guerreiro"));
       
       //Oráculo
       Oraculo orac = new Oraculo();
       orac.setNome("Oráculo Master");
       orac.guerreiro = g1;
       
       g1.oraculo = orac;
       
       orac.setVidas();
       InOut.MsgSemIcone(orac.nome, orac.prologoIntroducao());
       orac.loadLevel1();
       InOut.MsgSemIcone(orac.nome, orac.prologoIntroducao());
       orac.loadLevel2(InOut.leString("Você escolhe PAR ou ÍMPAR?").toUpperCase());
       
       if(g1.getVidas() != 0)
       {
           InOut.MsgSemIcone(orac.nome, orac.prologoVencedor());
       }
    }
    
}
